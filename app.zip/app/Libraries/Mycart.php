<?php
namespace App\Libraries;

use CodeIgniterCart\Cart;

class Mycart extends Cart {

    public $productNameSafe = false;

}