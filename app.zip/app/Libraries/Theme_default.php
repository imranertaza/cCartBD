<?php namespace App\Libraries;

class Theme_default{

    public $slider_width ='837';
    public $slider_height ='394';

    public $logo_width ='261';
    public $logo_height ='70';

    public $product_image = array(
        array(
            'width'=>'191',
            'height'=>'191',
        ),
        array(
            'width'=>'198',
            'height'=>'198',
        ),
        array(
            'width'=>'100',
            'height'=>'100',
        ),
        array(
            'width'=>'437',
            'height'=>'400',
        ),
    );

}