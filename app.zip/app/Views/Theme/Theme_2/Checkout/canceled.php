<section class="main-container checkout" id="tableReload">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img src="<?php echo base_url()?>/assets/img/cancel.svg" alt="success">
            </div>
            <div class="col-md-6 text-center align-self-center">
                <div class="message">
                    <img src="<?php echo base_url()?>/assets/img/can.svg" alt="success">
                    <p class="can-title">cancel !</p>
                    <p class="suc-message">Your order Canceled</p>
                    <a href="<?php echo base_url()?>" class="btn bg-black text-white" style="width:175px;" ><img src="<?php echo base_url()?>/assets/img/aroue.svg" alt="success"> Back to home</a>
                </div>
            </div>
        </div>
    </div>
</section>