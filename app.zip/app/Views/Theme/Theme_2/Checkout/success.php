<section class="main-container checkout" id="tableReload">
    <div class="container">
        <div class="row">
<!--            <div class="col-md-6 text-center">-->
<!--                <img src="--><?php //echo base_url()?><!--/assets/img/success.svg" alt="success">-->
<!--            </div>-->
            <div class="col-md-3 text-center"></div>
            <div class="col-md-6 text-center align-self-center">
                <div class="message">
                    <img src="<?php echo base_url()?>/assets/img/suc_si.svg" alt="success">
                    <p class="suc-title">Done !</p>
                    <p class="suc-message">Your order successfully placed</p>
                    <a href="<?php echo base_url()?>" class="btn bg-black text-white mt-3" style="width:175px;" ><img src="<?php echo base_url()?>/assets/img/aroue.svg" alt="success"> Back to home</a>
                    <br>
                    <br>
                    <b>আপনার অর্ডারের ট্রাকিং অথবা বর্তমান অবস্থা জানতে আমাদের গ্রুপে জয়েন করুন।</b>
                    <br>
                    <a href="https://chat.whatsapp.com/H0Fiyen0gp26M5H3hTFTdB" target="_blank" style="color: #00A650;" ><b>Whatsapp Group</b></a>
                    <br>
                    <b>এছাড়াও আপনার মূল্যবান মতামত ও অভিযোগ থাকলে আমাদেরকে জানাতে পারেন এই গ্রুপের মাধ্যমে।</b>
                    <br>
                    <a href="https://www.facebook.com/groups/1025451975373703" target="_blank" style="color: #00A650;" ><b>Facebook Group</b></a>
                    <br>
                    <b>আরো কালেকশন দেখতে আমাদের ওয়েবসাইট ভিজিট করতে পারেন।</b>
                    <br>
                    <a href="https://deshirotno.com/" target="_blank" style="color: #00A650;" ><b>Website</b></a>
                    <br>
                </div>
            </div>
            <div class="col-md-3 text-center"></div>
        </div>
    </div>
</section>